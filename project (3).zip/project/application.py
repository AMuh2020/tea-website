
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, usd

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True


# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///tea-web.db")

# is for showing the loggend in user on each page (dont know any other way)
#try:
#   username = session["username"]
#   return render_template("index.html", username=username)
#except:
# pass


@app.route("/")
def index():
    try:
        username = session["username"]
        return render_template("index.html", username=username)
    except:
        pass

    return render_template("index.html")

@app.route("/contact")
def contact():
    try:
        username = session["username"]
        return render_template("contact.html", username=username)
    except:
        pass
    return render_template("contact.html")


@app.route("/order", methods=["GET", "POST"])
@login_required
def order():
    if request.method == "POST":
        total = request.form.get("total")
        teas = ["earl","earll","english","englishl","assam","assaml","dragon","dragonl","sencha","senchal","matcha","matchal","rooibos","rooibosl","peppermint","peppermintl","hibiscus","hibiscusl"]
        teas_long = ["Earl Grey","Earl Grey Large","English Breakfast","English Breakfast Large","Assam Tea","Assam Tea Large","Dragonwell Tea","Dragonwell Tea Large","Sencha","Sencha Large","Matcha","Matcha Large","Rooibos Tea","Rooibos Tea Large","Peppermint Tea","Peppermint Tea Large","Hibiscus Tea","Hibiscus Tea Large"]
        items = []
        each = {}
        # for jinja2 later to make table for /confirmation
        teas_in = []
        # seems to be a problem with using long keys for dictionary or with request.form.get or with name
        teas_in_long = []
        for i in range(len(teas)):
            name = teas[i]
            name_long = teas_long[i]
            item = request.form.get(name)
            if item != None:
                each[name] = item
                items.append(each)
                teas_in.append(name)
                teas_in_long.append(name_long)
                each = {}

        print(items)
        print(teas_in)
        print(total)
        session["items"] = items
        session["teas_in"] = teas_in
        session["teas_in_long"] = teas_in_long
        session["total"] = total
        return redirect("/confirmation")
    else:
        username = session["username"]

        return render_template("order.html", username=username)

@app.route("/confirmation", methods=["GET", "POST"])
def confirmation():

    if request.method == "POST":
        items = session["items"]
        teas_in = session["teas_in"]
        teas_in_long = session["teas_in_long"]
        total = session["total"]

        user_id = session["user_id"]

        check = db.execute("SELECT MAX(order_id) FROM orders")
        print(check[0]["MAX(order_id)"])
        if check[0]["MAX(order_id)"] == None:
            print(db.execute("SELECT MAX(order_id) FROM orders"))
            order_number = 0
        else:
            change = db.execute("SELECT MAX(order_id) FROM orders")
            order_number = int(change[0]["MAX(order_id)"]) + 1
            print(order_number)

        for i in range(len(items)):
            db.execute("INSERT INTO orders (user_id, tea, order_id, tea_price, order_total) VALUES(?,?,?,?,?)", user_id, teas_in_long[i], order_number, items[i][teas_in[i]], total )

        order_number = order_number + 1
        return redirect("/")
    else:
        items = session["items"]
        teas_in = session["teas_in"]
        teas_in_long = session["teas_in_long"]
        total = session["total"]

        username = session["username"]
        print(total + "|" + str(type(total)))
        total = float(total)
        return render_template("confirmation.html", items=items, teas=teas_in, teas_long=teas_in_long, total=total, username=username)

@app.route("/black-tea")
def black_tea():
    try:
        username = session["username"]
        return render_template("black_tea.html", username=username)
    except:
        pass

    return render_template("black_tea.html")

@app.route("/history")
@login_required
def history():
    user_id = session["user_id"]
    table = db.execute("SELECT * FROM orders WHERE user_id = ?", user_id)
    print(table)

    username = session["username"]
    return render_template("order_history.html", info=table, username=username)

@app.route("/admin", methods=["GET", "POST"])
@login_required
def admin():
    page = ["orders normal","orders search","users"]
    if request.method == "POST":
        user_specified = request.form.get("user")
        print("user_s: " + str(user_specified) + " " + str(type(user_specified)))
        print(request.form.get("page"))

        if request.form.get("page") == None or request.form.get("page") == "Orders":
            print("FROM ORDERS")
            if user_specified != None:
                print("IN THE IF")
                print("user_s3: " + str(user_specified) + " " + str(type(user_specified)))
                page = page[1]
                user_id_search = db.execute("SELECT id FROM users WHERE username = ?", user_specified)
                # search through users to find the user_id of user that was posted
                user_id_search = user_id_search[0]["id"]

                table = db.execute("SELECT * FROM orders WHERE user_id = ?", user_id_search)
                print(table)
                return render_template("admin.html", info=table, user_specified=user_specified, page=page)

        elif request.form.get("page") == "Users":
            page = page[2]
            users = db.execute("SELECT id,username FROM users")

            username = session["username"]
            return render_template("admin.html", page=page, users=users, username=username)


        return redirect("/admin")
    else:
        page = page[0]
        user_id = session["user_id"]
        if user_id != 1:
            return redirect("/")
        table = db.execute("SELECT * FROM orders")
        usernames_id = db.execute("SELECT id,username FROM users")
        print(usernames_id)
        username_user_id = {}
        for i in range(len(usernames_id)):
            username_user_id[usernames_id[i]["id"]] = usernames_id[i]["username"]
        print("HERE!: " + str(username_user_id))

        username = session["username"]
        return render_template("admin.html", info=table, usernames=username_user_id, page=page, username=username)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")

        # Ensure username was submitted
        if not username:
            return apology("must provide username", 400)
        # Ensure password was submitted
        elif not password:
            return apology("must provide password", 400)
        elif len(password) < 8:
            return apology("password is too short", 400)
        elif not request.form.get("confirmation"):
            return apology("must re enter password", 400)
        # checks if password and confirmation password are the same
        elif password != request.form.get("confirmation"):
            return apology("password is not the same", 400)

        #️generates hash for the password
        hashed = generate_password_hash(request.form.get("password"))

        # Insert username and password (hashed) into database
        try:
            db.execute("INSERT INTO users (username, hash) VALUES(?,?)", username, hashed)
        except:
            return apology("ERROR")

        return redirect('/login')
    else:
        return render_template('register.html')


@app.route("/login", methods=["GET", "POST"])
def login():

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        session["username"] = request.form.get("username")

        # Redirect user to home page
        return redirect("/")
    else:
        return render_template('login.html')

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")